$(function(){
  var st = Date.now();

  var lastApis = new ChromeWebUIApis({
    methods: 'queryUnClosedPages,deleteUnClosedPageById,clearAllUnClosedPages,openUrl',
    onerror: function(ev) {
      console.log('error:', arguments);
    },
    onbefore: function(ev) {
      console.log('before call:' + ev.methodName, ev.args);
    }
  });

  var navItemFn = doT.template($('#nav-item').html()),
  urlListFn = doT.template($('#url-list').html());

  var dataDict = {};
  var reloadData = function(selectedDay){
    lastApis.queryUnClosedPages(function(data){
      console.log('queryUnClosedPages 回调函数被调用:', Date.now() - st + 'ms(距页面打开)', arguments);
      if (data.length == 0) {
        data = [{day:Date.now() / 1000, data:[]}];
        $('#clear-all,#btn-open-all').attr('disabled', 'disabled');
      } else {
        data = data.slice(0, 7);
      }
      if (data.length == 1) {
        $('ul.nav').hide();
      } else {
        $('ul.nav').show();
      }
      $('.nav').html(navItemFn(data));

      dataDict = {};
      data.forEach(function(item){
        dataDict[item.day] = item.data;
      });

      var sel = $('.nav a[day=' + selectedDay + ']');
      if(sel.length == 0) {
        sel = $('.nav a:first');
      }
      sel.trigger('click');
    });
    
    return arguments.callee;
  }();
  
  function renderDay(day) {
    var INTERVAL = 60;
    var list = dataDict[day];
    
    var group = [];
    var firstTime = Number.MAX_VALUE;
    var map = {};
    list.forEach(function(item){
      if ((firstTime - item.time) > INTERVAL) {
        firstTime = item.time;
        group.push([]);
        map = {};
      }
      if (map[item.url]) {
        lastApis.deleteUnClosedPageById(item.id);
      } else {
        map[item.url] = true;
        group[group.length-1].push(item);
      }
    });

    $('#list-last').html(urlListFn([group[0]]));
    $('#list-more').html(urlListFn(group.slice(1, group.length)));
    if (group.length > 1) {
      $('div.more').show();
    } else {
      $('div.more').hide();
    }
    if (!group[0] || group[0].length == 0) {
      $('#empty-data').show();
    }
  }

  $('#clear-all').click(function(){
    lastApis.clearAllUnClosedPages(function(){
      reloadData();
    });
  });
  $('#goto-history').click(function(){
    lastApis.openUrl('se://history/', 0, 0, 0);
  });
  $('#btn-open-all').click(function(){
    $('#list-last li div a').each(function(){
      $(this).css('color', '#999');
      lastApis.openUrl($(this).attr('href'), 2, 2, 0);
    });
  });
  $('.list li a[href]').live('click', function(){
    $(this).css('color', '#999');
    var url = $(this).attr('href') || '';
    if (url.substr(0, 7) == 'file://') {
      lastApis.openUrl(url, 1, 2, 0);
      return false;
    }
  });
  $('#btn-more').click(function(){
    $('#list-more').slideToggle('fast');
  });
  $('.nav a').live('click', function(){
    $('.nav a').removeClass('selected');
    $(this).addClass('selected');
    renderDay($(this).attr('day'));
  });
  $('.remove').live('click', function(){
    lastApis.deleteUnClosedPageById(parseInt($(this).attr('url-id')), function(){
      reloadData($('.nav a.selected').attr('day'));
    });
    $(this).parents('li').remove();
  });
});

function formatNavDay(timestamp) {
  timestamp = timestamp * 1000;
  var now = new Date();
  var d = new Date(timestamp);
  var nowDay = Math.floor((now.getTime() + 1000 *60*60*8) / (1000 *60*60*24));
  var dDay = Math.floor((d.getTime() + 1000 *60*60*8) / (1000 *60*60*24));
  var arr = ['今天', '昨天', '前天'];
  var ret = arr[nowDay - dDay];
  if (!ret) {
    ret = (d.getMonth()+1) + '月' + d.getDate() + '日';
  }
  return ret;
}
function formatTime(timestamp) {
  timestamp = timestamp * 1000;
  var d = new Date(timestamp);
  var m = d.getMinutes();
  if (m < 10) {
    m = '0' + m;
  }
  return d.getHours() + ':' + m;
}
