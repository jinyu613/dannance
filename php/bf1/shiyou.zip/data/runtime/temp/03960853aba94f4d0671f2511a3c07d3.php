<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"C:\Users\Administrator\Desktop\shiyou/app/admin\view\plug\ajax_plug_link_list.html";i:1481587604;}*/ ?>
<?php if(is_array($plug_link) || $plug_link instanceof \think\Collection): if( count($plug_link)==0 ) : echo "" ;else: foreach($plug_link as $key=>$v): ?>
	<tr>
		<td height="28" ><?php echo $v['plug_link_id']; ?></td>
		<td><?php echo $v['plug_link_name']; ?></td>
		<td><a href="<?php echo $v['plug_link_url']; ?>" target="_blank"><?php echo $v['plug_link_url']; ?></a></td>
		<td class="hidden-sm hidden-xs"><?php echo $v['plug_link_qq']; ?></td>
		<td class="hidden-xs"><?php echo $v['plug_linktype_name']; ?></td>
		<td class="hidden-xs"><?php echo $v['plug_link_l']; ?></td>
		<td class="hidden-sm hidden-xs"><?php echo date('Y-m-d',$v['plug_link_addtime']); ?></td>
		<td class="hidden-xs">
			<?php if($v['plug_link_open'] == 1): ?>
				<a class="red open-btn" href="<?php echo url('plug_link_state'); ?>" data-id="<?php echo $v['plug_link_id']; ?>" title="已开启">
					<div id="zt<?php echo $v['plug_link_id']; ?>"><button class="btn btn-minier btn-yellow">开启</button></div>
				</a>
				<?php else: ?>
				<a class="red open-btn" href="<?php echo url('plug_link_state'); ?>" data-id="<?php echo $v['plug_link_id']; ?>" title="已禁用">
					<div id="zt<?php echo $v['plug_link_id']; ?>"><button class="btn btn-minier btn-danger">禁用</button></div>
				</a>														<?php endif; ?>														</td>
		<td>
			<div class="hidden-sm hidden-xs action-buttons">
				<a class="green linkedit-btn"  href="<?php echo url('plug_link_edit'); ?>" data-id="<?php echo $v['plug_link_id']; ?>"  title="修改">
					<i class="ace-icon fa fa-pencil bigger-130"></i>																</a>
				<a class="red confirm-rst-url-btn" data-info="你确定要删除吗？" href="<?php echo url('plug_link_del',array('plug_link_id'=>$v['plug_link_id'])); ?>" title="删除">
					<i class="ace-icon fa fa-trash-o bigger-130"></i>																</a>										</div>
			<div class="hidden-md hidden-lg">
				<div class="inline position-relative">
					<button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown" data-position="auto">
						<i class="ace-icon fa fa-cog icon-only bigger-110"></i>
					</button>
					<ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
						<li>
							<a href="<?php echo url('plug_link_edit'); ?>" data-id="<?php echo $v['plug_link_id']; ?>" class="tooltip-success linkedit-btn" data-rel="tooltip" title="" data-original-title="修改">
											<span class="green">
												<i class="ace-icon fa fa-pencil bigger-120"></i>
											</span>
							</a>
						</li>

						<li>
							<a href="<?php echo url('plug_link_del',array('plug_link_id'=>$v['plug_link_id'])); ?>"  class="tooltip-error confirm-rst-url-btn" data-rel="tooltip" title="" data-info="你确定要删除吗？" data-original-title="删除">
											<span class="red">
												<i class="ace-icon fa fa-trash-o bigger-120"></i>
											</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</td>
	</tr>
<?php endforeach; endif; else: echo "" ;endif; ?>
	<tr>
		<td height="50" colspan="12" align="left"><?php echo $page; ?></td>
	</tr>

